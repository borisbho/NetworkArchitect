﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//1)Upon startup, your application must prompt the user for the path to a text file containing the network data. 




namespace NetworkArchitect
{
    public class Driver
    {
        public static void Main(string[] args)
        {
            Network n = new Network();
            n.BuildNetworks(ReadFile());

        }
        public static string ReadFile()
        {
            string file = "C:\\Users\\Boris Ho\\Documents\\WorkSpace\\NetworkArchitect\\NetworkArchitect\\arc.txt";
            return file;
        }
    }
}
