﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkArchitect
{
    public class Network
    {
        public List<Node> AllNodes = new List<Node>();
        public List<string> Cycles = new List<string>();
        public void FindNetwork()
        {
            List<string> VisitedNodes = new List<string>();
            List<Edge> myEdge = new List<Edge>();

            //Making sure connections dont repeat and create new edges with connections and weight
            foreach (Node n in AllNodes)
            {
                VisitedNodes.Add(n.NodeID);
                for (int i = 0; i < n.NodesConnected.Count; i++)
                {
                    if (!VisitedNodes.Contains(n.NodesConnected[i].NodeID))
                    {
                        Edge newEdge = new Edge(n, n.NodesConnected[i], n.NodesConnected[i].CableLength);

                        n.Edges.Add(newEdge);
                    }
                }
            }

            //Collecting list of all Edges
            for (int i = 0; i < AllNodes.Count; i++)
            {
                foreach (Edge item in AllNodes[i].Edges)
                {
                    myEdge.Add(item);
                }
            }

            //Sorting List of Edges and determining which edges can connect without a cycle
            List<Edge> kk = myEdge.OrderBy(x => x.Weight).ToList();
            int weight = 0;
            foreach (Edge item in kk)
            {
                if (HasCycle(item.FirstNode.NodeID, item.SecondNode.NodeID))
                {
                    Console.WriteLine(item.FirstNode.NodeID + "->" + item.SecondNode.NodeID + " Weight: " + item.Weight);
                    weight += item.Weight;
                }

            }
            Console.WriteLine("Cable Needed: " + weight + "ft\n\n" );

        }
        public bool HasCycle(string a, string d)
        {
            if (!Cycles.Contains(d))
            {
                Cycles.Add(a);
                Cycles.Add(d);
                return true;
            }
            else
            {

                return false;
            }

        }
        public void BuildNetworks(string file)
        {
            List<string> AllInputs = new List<string>();
            List<string> VisitedNodes = new List<string>();
            string[] ArrayOfInputs;

            //Reading the file and Storing all the inputs line by line
            foreach (string s in System.IO.File.ReadLines(file))
            {
                ArrayOfInputs = new string[s.Length];
                ArrayOfInputs[0] = s.Replace(",", " ");
                AllInputs.Add(ArrayOfInputs[0]);
            }

            //Creating new nodes and adding all nodes connected for that node including the cable length. Then adding to allNodes list.
            for (int i = 1; i < AllInputs.Count; i++)
            {
                string[] arrayOfInputSplit;
                string[] ss = AllInputs[i].Split(' ').ToArray();
                Node newNode = new Node(ss[0], 0);
                for (int k = 1; k < AllInputs[i].Split(' ').ToArray().Length; k++)
                {
                    arrayOfInputSplit = ss[k].Split(':').ToArray();

                    newNode.NodesConnected.Add(new Node(arrayOfInputSplit[0], int.Parse(arrayOfInputSplit[1])));
                }
                AllNodes.Add(newNode);
            }

            Console.WriteLine(this.ToString());
            FindNetwork();

        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (Node n in AllNodes)
            {
                sb.Append($"{n.ToString()}\n");
            }

            return sb.ToString();
        }
    }
}








/*
 * MST 1:
 * Socket Set: AX1, AX4, AX2, AX3, AX5
 * Cable Needed: 24ft
 * Optimal Hub Placement: AX4 (9-15)
 * 
 * MST 2:
 * Socket Set: AX10, AX11, AX12, AX99, AX100
 * Cable Needed: 23ft
 * Optimal Hub Placement: AX99 (8-15)
 * 
 * Total Cable Required: 47ft
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * AX10,AX11:2,AX12:4
AX11,AX10:2,AX12:2
AX12,AX10:4,AX11:2,AX99:4
AX99,AX12:4,AX100:15
AX100,AX99:15
 */






