﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkArchitect
{
    public class Node
    {
        public string NodeID { get; set; }
        public int CableLength { get; set; }
        public List<Node> NodesConnected { get; set; }
        public List<Edge> Edges { get; set; }
        public Node(string n, int c)
        {
            this.NodeID = n;
            this.CableLength = c;
            this.NodesConnected = new List<Node>();
            this.Edges = new List<Edge>();
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"Node: {this.NodeID} - ");

            foreach (Node n in NodesConnected)
            {
                if (n == NodesConnected[NodesConnected.Count - 1])
                {
                    sb.Append(n.NodeID + ":" + n.CableLength);
                }
                else
                {
                    sb.Append($"{n.NodeID}:{n.CableLength}, ");
                }
            }

            return sb.ToString();
        }


    }
}


 