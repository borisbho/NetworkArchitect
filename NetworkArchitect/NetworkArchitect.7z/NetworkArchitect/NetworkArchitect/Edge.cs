﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkArchitect
{
    public class Edge : IComparable
    {
        public Node FirstNode { get; set; }
        public Node SecondNode { get; set; }
        public int Weight { get; set; }

        public Edge(Node f, Node s, int w)
        {
            this.FirstNode = f;
            this.SecondNode = s;
            this.Weight = w;
        }

        public int CompareTo(object obj)
        {
            Edge edgy = obj as Edge;
            if(edgy.Weight < Weight)
            {
                return 1;
            }
            if(edgy.Weight > Weight)
            {
                return -1;
            }
            return 0;
         }
    }
}
